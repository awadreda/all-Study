using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Bank_Presentation_Layer_Web_App.Pages.Client
{
    public class SettingsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
