using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Bank_Presentation_Layer_Web_App.Pages.Start
{
    public class EmailVerificationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
