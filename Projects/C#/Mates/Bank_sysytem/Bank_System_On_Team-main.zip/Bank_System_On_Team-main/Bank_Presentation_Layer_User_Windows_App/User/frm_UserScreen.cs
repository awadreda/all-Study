﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_Presentation_Layer_User_Windows_App
{
    public partial class frm_UserScreen : Form
    {
        public frm_UserScreen()
        {
            InitializeComponent();
        }
    }
}
