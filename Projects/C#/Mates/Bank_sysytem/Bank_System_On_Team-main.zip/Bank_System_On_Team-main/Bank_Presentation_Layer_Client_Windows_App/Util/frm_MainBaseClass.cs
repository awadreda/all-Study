﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_Presentation_Layer_Windows_App.Util
{
    public partial class frm_MainBaseForm : Form
    {
        public frm_MainBaseForm()
        {
            InitializeComponent();
        }

        internal clsPagesControler controler = null;

    }
}
